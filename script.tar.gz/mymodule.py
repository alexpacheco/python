foo = 100
 
def hello():
    print("i am from mymodule.py")


