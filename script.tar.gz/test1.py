fin = open('bad.txt')
for line in fin:
    print(line)
fin.close()
    
print('Hello World!')
